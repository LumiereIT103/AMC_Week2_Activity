import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Pathrick Gian E. De Guzman");
  const bodyText = "Role ko sa Sysarch ay mag aya mag aral <3 ginagabayan ko mga kagroup ko sa tamang way pano mag make ng system. I love this School ";

  const onPressTitle = () => {
    setTitleText("Pathrick Gian E. De Guzman [pressed]");
  };


return (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
    <Text style={styles.titleText, styles.highLightBlue} onPress={onPressTitle}>
    {titleText}
    {'\n'}
    {'\n'}
      </Text>
        <Text style={styles.highLight1} >20 Years Old <Text style={styles.baseText} > September 24, 2004 is my Birthday</Text></Text> 
        <Text style={styles.baseText} numberOfLines = {4}>{bodyText}<Text style={styles.highLightRed} >Global Reciprocal College is the best.</Text>
        
        
        </Text>
       
    </SafeAreaView>
  </SafeAreaProvider>
);
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, alignItems: 'center',
    },
    baseText: {
      fontFamily: 'Conchin',    
    },
    highLightBlue:{color: 'blue', fontSize:25,
    fontWeight: 'bold', },
  highLightRed:{  fontFamily: 'Conchin',  color: 'red',},
  highLight1:{  fontFamily: 'Conchin',  color: 'orange',},
  
});

export default TextInANest;