import React from 'react';
import {Text, View, Image, ScrollView, TextInput} from 'react-native';


const YourApp = ()  =>{
return(
  <ScrollView  >
  <View style={{
        
        justifyContent: 'center',
        alignItems: 'center',
      }}>
  <Text > Pathrick Text</Text>
  </View>
  <View
  style={{
        
        justifyContent: 'center',
        alignItems: 'center',
      }}> 
  <Text>
  Pathrick Makhulet
  </Text>
  <Image source={{uri: 'https://reactjs.org/logo-og.png'}}
       style={{width: 150, height: 150, }} />

  </View>
  <View style={{
        
        justifyContent: 'center',
        alignItems: 'center',
      }}>
  <TextInput 
  style = {{height: 40, justifyContent: 'center',
  textAlign: 'center',
   borderColor: 'gray', borderWidth:1, }}
  defaultValue="You can type in me"/>
  </View>
  </ScrollView>
);
}; 
export default YourApp;
