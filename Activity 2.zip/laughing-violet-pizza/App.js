import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Pathrick Gian E. De Guzman");
  const bodyText = "20 Years Old, Role ko sa Sysarch ay mag aya mag aral <3 ginagabayan ko mga kagroup ko sa tamang way pano mag make ng system. I love this School Global Reciprocal College is the best. ";
  const onPressTitle = () => {
    setTitleText("Pathrick Gian E. De Guzman [pressed]");
  };


return (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
    <Text style={styles.titleText} onPress={onPressTitle}>
    {titleText}
    {'\n'}
    {'\n'}
      </Text>
        <Text style={styles.baseText} numberOfLines = {5}>{bodyText}</Text>
    </SafeAreaView>
  </SafeAreaProvider>
);
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, alignItems: 'center',
    },
    baseText: {
      fontFamily: 'Conchin',    
    },
  titleText:{
    fontSize:25,
    fontWeight: 'bold',
  },
});

export default TextInANest;